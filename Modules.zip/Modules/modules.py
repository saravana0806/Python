# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 14:34:21 2024

@author: HP
"""

def average(x):
    sumofx = sum(x)
    n = len(x)
    average = sumofx/n
    return average