# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 11:34:11 2024

@author: HP
"""

def multiply(x, y):
    return x * y