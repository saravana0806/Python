# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 11:33:36 2024

@author: HP
"""

def add(x, y):
    return x + y
