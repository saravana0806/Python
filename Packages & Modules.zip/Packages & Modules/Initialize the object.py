# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 11:38:52 2024

@author: HP
"""

class Car:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year
        self.is_running = False

    def start_engine(self):
        self.is_running = True
        print(f"The {self.year} {self.make} {self.model}'s engine is now running.")

# Creating an object of the Car class
my_car = Car(make="Toyota", model="Camry", year=2022)

# Accessing the attributes
print(f"Make: {my_car.make}")
print(f"Model: {my_car.model}")
print(f"Year: {my_car.year}")
print(f"Is Running: {my_car.is_running}")

# Starting the engine
my_car.start_engine()
print(f"After starting the engine, is_running: {my_car.is_running}")


