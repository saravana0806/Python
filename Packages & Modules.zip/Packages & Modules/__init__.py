# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 11:34:35 2024

@author: HP
"""

from .module1 import add
from .module2 import multiply

