# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 11:35:22 2024

@author: HP
"""

from my_package import add, multiply

# Test the functions
result_add = add(5, 3)
result_multiply = multiply(2, 6)

# Display the results
print("Addition:", result_add)
print("Multiplication:", result_multiply)
