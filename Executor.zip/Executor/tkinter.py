{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "1b16376c-9ad7-4189-b61e-493a983e3850",
   "metadata": {},
   "outputs": [],
   "source": [
    "import tkinter as tk\n",
    "\n",
    "def on_button_click():\n",
    "    label.config(text=\"Button Clicked!\")\n",
    "\n",
    "# Create the main window\n",
    "root = tk.Tk()\n",
    "root.title(\"Tkinter Example\")\n",
    "\n",
    "# Create a button and attach an event handler\n",
    "button = tk.Button(root, text=\"Click Me!\", command=on_button_click)\n",
    "button.pack(pady=20)\n",
    "\n",
    "# Create a label to display messages\n",
    "label = tk.Label(root, text=\"Welcome to Tkinter!\")\n",
    "label.pack()\n",
    "\n",
    "# Start the main event loop\n",
    "root.mainloop()\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.5"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
